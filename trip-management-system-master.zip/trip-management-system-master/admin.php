<html>


<head>
<title>TRIP MANAGEMENT</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<style type="text/css">
body, html {
  height: 100%;
}

.bg { 
  /* The image used */
  background-image: url("admin.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}


</style>

</head>


<body class="bg">
	<div style=";padding-top: 50px; text-align: center;">
		<div class="alert alert-info" role="alert" style="height: 60px;font-size: 24px">

			<a href="signin.php">
			<button type="button" style="float: left;" class="btn btn-danger">BACK</button>
			</a>
			
			ADMIN CONSOLE
			<a href="signin.html">
			<img src="home.png" style="float: right; height: 35px">
			</a>
		
		</div>
	</div>
<div class="col-md-12" style=" background-color: white;padding-left: 30px;padding-top: 10px;padding-bottom: 10px;  margin: 0px" >

<div class="btn-group dropright" style="width: 100%">
  <button type="button" class="btn btn-secondary" disabled="true">
    SELECT A PROCEDURE
  </button>
</div><br/><br/>

<div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Details of All the Customer
        </button>
      </h2>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">


        <?php

        require_once 'dbconfig.php';
        $dbhost = 'localhost';
		$dbuser = 'root';
		$dbpass = '';
		$con=mysqli_connect("localhost","root","","project");
        try {
            // execute the stored procedure
            $sql = 'CALL proc_admin1';
            // call the stored procedure
            $q = $con->query($sql);
        } catch (PDOException $e) {
            die("Error occurred:" . $e->getMessage());
        }
		
        ?>
 
        <table class="table table-striped table-dark table-bordered">
          <thead class="thead-dark"><tr>
                <th>Customer Name</th>
                <th>Customer First Name</th>
                <th>Customer Last Name</th>
                <th>Customer Age</th>
                <th>Street Address</th>
                <th>Home City</th>
            </tr></thead>
            
            <tbody>
            <?php while ($r = $q->fetch_array()): ?>
                <tr>
                  <th scope="row"><?php echo $r['cust_id'] ?></th>
                    <td><?php echo $r['cust_fname'] ?></td>
                    <td><?php echo $r['cust_lname'] ?></td>
                    <td><?php echo $r['age'] ?></td>
                    <td><?php echo $r['street_address'] ?></td>
                    <td><?php echo $r['home_city'] ?></td>
                </tr>
            <?php endwhile; 
			mysqli_close($con);?>
            </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h2 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Details of a Specific Customer
        </button>
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <form method="POST">
	  <div class="card-body">
      	<div class="input-group mb-3">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="basic-addon1">ID of the CUSTOMER</span>
		  </div>
		  <input type="text" class="form-control" placeholder="Please Enter the ID of the Customer" aria-label="cust_id" name="cust_id" aria-describedby="basic-addon1">
		</div>
		<button type="submit" name="btnProc2" class="btn btn-success">SUBMIT</button><br/><br/>
 
        <table class="table table-striped table-dark table-bordered">
          <thead class="thead-dark"><tr>
                <th>Customer Name</th>
                <th>Customer First Name</th>
                <th>Customer Last Name</th>
                <th>Customer Age</th>
                <th>Street Address</th>
                <th>Home City</th>
            </tr></thead>
            
            <tbody>
            <?php 
				$con=mysqli_connect("localhost","root","","project");
				if(isset($_POST['btnProc2'])) 
				{
					$var1 = $_POST['cust_id'];
					$sqlresult = "CALL proc_admin2($var1)";
					$result = mysqli_query($con,$sqlresult);
					if($result->num_rows>0)
					{
						while($row = $result->fetch_assoc())
						{
							echo "<tr><td>".$row["cust_id"]."</td><td>".$row["cust_fname"]."</td><td>".$row["cust_lname"]."</td><td>".$row["age"]."</td><td>".$row["street_address"]."</td><td>".$row["home_city"]."</td></tr>";
						}
					}
				}
				mysqli_close($con);
			?>
            </tbody>
        </table>
      </div>
	  </form>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h2 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Details of a trip of a Customer
        </button>
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <form method="POST">
	  <div class="card-body">
      	<div class="input-group mb-3">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="basic-addon1">ID of the CUSTOMER</span>
		  </div>
		  <input type="text" class="form-control" placeholder="Please Enter the ID of the Customer" aria-label="cust_id" name="cust_id" aria-describedby="basic-addon1">
		</div><div class="input-group mb-3">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="basic-addon1">ID of the TRIP</span>
		  </div>
		  <input type="text" class="form-control" placeholder="Please Enter the ID of the Trip" aria-label="trip_id" name="trip_id" aria-describedby="basic-addon1">
		</div>
		<button type="submit" name="btnProc3" class="btn btn-success">SUBMIT</button><br/>
        <tbody>
            <?php 
			$con=mysqli_connect("localhost","root","","project");
				if(isset($_POST['btnProc3'])) 
				{
					$custid = $_POST['cust_id'];
					$tripid = $_POST['trip_id'];
					$sqlresult = "CALL proc_admin3($custid,$tripid)";
					$result = mysqli_query($con,$sqlresult);
					if($result->num_rows>0)
					{
						while($row = $result->fetch_assoc())
						{
							echo "<tr><td>".$row["cust_id"]."</td><td>".$row["cust_fname"]."</td><td>".$row["cust_lname"]."</td><td>".$row["age"]."</td><td>".$row["street_address"]."</td><td>".$row["home_city"]."</td><td>".$row["login_status"]."</td><td>".$row["trip_id"]."</td><td>".$row["trip_start"].$row["trip_end"]."</td><td>".$row["people_traveling"]."</td><td>".$row["budget"]."</td></tr>";
						}
					}
				}
				mysqli_close($con);
			?>
            </tbody>
      </div>
	  </form>
    </div>
  </div>
</div>
<div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingFour">
      <h2 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          Details of Ongoing Trip
        </button>
      </h2>
    </div>

    <div id="collapseFour" class="collapse " aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="card-body">

		

        SHOW TABLE
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingFive">
      <h2 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
          Trips Between two dates
        </button>
      </h2>
    </div>
    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
      <div class="card-body">

		<div class="input-group mb-3">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="basic-addon1">START DATE</span>
		  </div>
		  <input type="date" class="form-control" placeholder="Please Enter the START DATE" aria-label="start_date" name="start_date" aria-describedby="basic-addon1">
		</div><div class="input-group mb-3">
		  <div class="input-group-prepend">
		    <span class="input-group-text" id="basic-addon1">END DATE</span>
		  </div>
		  <input type="date" class="form-control" placeholder="Please Enter the END DATE" aria-label="end_date" name="end_date" aria-describedby="basic-addon1">
		</div>
<button type="button" class="btn btn-success">SUBMIT</button><br/>

        SHOW TABLE
      </div>
    </div>
  </div>
</div>
<!--

-->

</div>

</body>


</html>