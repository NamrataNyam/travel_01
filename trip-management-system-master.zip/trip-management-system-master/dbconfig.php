<?php
    $host = 'localhost';
    $dbname = 'project';
    $username = 'root';
    $password = '';